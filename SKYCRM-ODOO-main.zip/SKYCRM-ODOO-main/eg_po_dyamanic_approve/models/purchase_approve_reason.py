from odoo import models, fields

class PurchaseApproveReason(models.TransientModel):
    _name = 'purchase.approve.reason'
    _description = 'Purchase Approve Reason'

    reason = fields.Text(string='Reason')
    def action_confirm_reason(self):
        reason_wizard = self.env['purchase.approve.reason'].browse(self._context.get('active_id'))
        action_type = self._context.get('action')

        if reason_wizard:
            reason = reason_wizard.reason

            if action_type == 'disapprove':
                # Write the reason to the purchase order logs for disapproval
                self.message_post(body=f"Order disapproved with reason: {reason}")
                self.write({'state': 'disapproved'})

                # Update the state of the approval line to 'cancel'
                user_approve_line = self.purchase_approve_line.filtered(lambda l: l.partner_id.id == self.env.user.partner_id.id)
                user_approve_line.write({'state': 'cancel'})
            elif action_type == 'approve':
                user_approve_line = self.purchase_approve_line.filtered(lambda l: l.partner_id.id == self.env.user.partner_id.id)

                if user_approve_line:
                    max_approval_amount = user_approve_line.max_amount

                    if self.amount_total <= max_approval_amount:
                        user_approve_line.write({'state': 'done'})
                        self.write({'state': 'second approve'})
                    else:
                        raise UserError(_("Order amount exceeds the maximum approval limit for the logged-in user"))
                else:
                    raise UserError(_("Sorry, you don't have access for approve %s Order") % self.name)

        return {'type': 'ir.actions.act_window_close'}
    
