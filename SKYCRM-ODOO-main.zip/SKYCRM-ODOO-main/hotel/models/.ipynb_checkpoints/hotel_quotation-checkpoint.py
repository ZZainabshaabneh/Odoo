import time
from datetime import timedelta


from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.misc import get_lang
from datetime import datetime, timedelta
from itertools import groupby
import json
from odoo import SUPERUSER_ID, _
from odoo.exceptions import AccessError
from odoo.osv import expression
from odoo.tools import float_is_zero, html_keep_url, is_html_empty

from odoo.addons.payment import utils as payment_utils


class QuotationRoomLine(models.Model):

    _name = "quotation.room.line"
    _description = "Hotel Room Reservation"
    _rec_name = "room_id"

    room_id = fields.Many2one("hotel.room", ondelete="restrict", index=True)
    check_in = fields.Datetime("Start Date", required=True)
    check_out = fields.Datetime("End Date", required=True)
    quotation_id = fields.Many2one("hotel.quotation", "Quotation Number", ondelete="cascade")
    status = fields.Selection(related="quotation_id.state", string="state")


class HotelQuotation(models.Model):

    _name = "hotel.quotation"
    _description = "hotel quotation"
#     _rec_name = "quotation_id"
    _order = "reservation_id desc"

    
    def name_get(self):
        res = []
        fname = ""
        for rec in self:
            fname = rec.name +" "+ "[" + rec.reservation_id.project_name + "]"
#             fname = str(rec.name)
            res.append((rec.id, fname))
        return res
    
    reservation_id = fields.Many2one(
        "hotel.reservation", "Reservation NO", ondelete="restrict"
    )
    
    
    @api.model
    def name_search(self, name="", args=None, operator="ilike", limit=100):
        if args is None:
            args = []
        args += [("name", operator, name)]
        folio = self.search(args, limit=100)
        return folio.name_get()
    
    def write(self, vals):
        res = super(HotelQuotation, self).write(vals)
        reservation_line_obj = self.env["hotel.room.reservation.line"]
        for folio in self:
            reservations = reservation_line_obj.search(
                [("reservation_id", "=", folio.reservation_id.id)]
            )
            if len(reservations) == 1:
                for line in folio.reservation_id.reservation_line:
                    for room in line.reserve:
                        vals = {
                            "room_id": room.id,
                            "check_in": folio.checkin_date,
                            "check_out": folio.checkout_date,
                            "state": "assigned",
                            "reservation_id": folio.reservation_id.id,
                        }
                        reservations.write(vals)
        return res
    
    @api.model
    def _get_checkin_date(self):
        self._context.get("tz") or self.env.user.partner_id.tz or "UTC"
        checkin_date = fields.Datetime.context_timestamp(self, fields.Datetime.now())
        return fields.Datetime.to_string(checkin_date)

    @api.model
    def _get_checkout_date(self):
        self._context.get("tz") or self.env.user.partner_id.tz or "UTC"
        checkout_date = fields.Datetime.context_timestamp(
            self, fields.Datetime.now() + timedelta(days=1)
        )
        return fields.Datetime.to_string(checkout_date)
    
    name = fields.Char("Quotation Number", readonly=True, index=True, default="New")
    user_id = fields.Many2one(
        'res.users', string='Salesperson', index=True, tracking=2, default=lambda self: self.env.user,
        domain=lambda self: "[('groups_id', '=', {}), ('share', '=', False), ('company_ids', '=', company_id)]".format(
            self.env.ref("sales_team.group_sale_salesman").id
        ),)
    
    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
        ], string='Status', readonly=True, copy=False, index=True, default='draft')
    
    checkin_date = fields.Datetime(
        "Start Date",
        required=True,
        readonly=True,
        state={"draft": [("readonly", False)]},
        default=_get_checkin_date,
    )
    checkout_date = fields.Datetime(
        "End Date",
        required=True,
        readonly=True,
        state={"draft": [("readonly", False)]},
        default=_get_checkout_date,
    )
    room_line_ids = fields.One2many(
        "hotel.quotation.line",
        "quotation_id",
        readonly=True,
        states ={"draft": [("readonly", False)], "sent": [("readonly", False)]},
        help="Hotel room reservation detail.",
        copy=True,
    )
#     service_line_ids = fields.One2many(
#         "hotel.service.line",
#         "folio_id",
#         readonly=True,
#         state={"draft": [("readonly", False)], "sent": [("readonly", False)]},
#         help="Hotel services details provided to"
#         "Customer and it will included in "
#         "the main Invoice.",
#     )

# service_line_ids = fields.One2many(
#         "hotel.service.line",
#         "folio_id",
#         readonly=True,
#         state={"draft": [("readonly", False)], "sent": [("readonly", False)]},
#         help="Hotel services details provided to"
#         "Customer and it will included in "
#         "the main Invoice.",
#     )

    hotel_policy = fields.Selection(
        [
            ("prepaid", "On Booking"),
            ("manual", "On Start Date"),
            ("picking", "On End Date"),
        ],
        default="manual",
        help="Hotel policy for payment that "
        "either the guest has to payment at "
        "booking time or check-in "
        "check-out time.",
    )
    duration = fields.Float(
        "Duration in Days",
        help="Number of days which will automatically "
        "count from the Start Date and End Date. ",
    )
    hotel_invoice_id = fields.Many2one("account.move", "Invoice", copy=False)
    duration_dummy = fields.Float()
    
    date_order = fields.Datetime(
        "Date Ordered",
        readonly=True,
        
        index=True,
        default=lambda self: fields.Datetime.now(),
    )
    
    company_id = fields.Many2one(
        "res.company",
        "Branch",
        readonly=True,
        index=True,
        
        default=1,
        states={"draft": [("readonly", False)]},
    )
    warehouse_id = fields.Many2one("stock.warehouse")
    currency_id = fields.Many2one(related='pricelist_id.currency_id', depends=["pricelist_id"], store=True, ondelete="restrict")
    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, compute='_amount_all')
    amount_tax = fields.Monetary(string='Taxes', store=True, compute='_amount_all')
    amount_total = fields.Monetary(string='Total', store=True, compute='_amount_all')
    client_order_ref = fields.Char(string='Customer Reference', copy=False)
    tax_totals_json = fields.Char(compute='_compute_tax_totals_json')
    
    
    
    partner_id = fields.Many2one(
        'res.partner', string='Customer', readonly=True,
        states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
        required=True, change_default=True, index=True, tracking=1,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)
    partner_invoice_id = fields.Many2one(
        'res.partner', string='Invoice Address',
        readonly=True, required=True,
        states={'draft': [('readonly', False)], 'sent': [('readonly', False)], 'sale': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)
    partner_shipping_id = fields.Many2one(
        'res.partner', string='Delivery Address', readonly=True, required=True,
        states={'draft': [('readonly', False)], 'sent': [('readonly', False)], 'sale': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)

    pricelist_id = fields.Many2one(
        'product.pricelist', string='Pricelist', check_company=True,  # Unrequired company
        required=True, readonly=True, states={'draft': [('readonly', False)], 'sent': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", tracking=1,
        help="If you change the pricelist, only newly added lines will be affected.")
    
    fiscal_position_id = fields.Many2one(
        'account.fiscal.position', string='Fiscal Position',
        domain="[('company_id', '=', company_id)]", check_company=True,
        help="Fiscal positions are used to adapt taxes and accounts for particular customers or sales orders/invoices."
        "The default value comes from the customer.")
#     user_id = partner_user.id
#     partner_user = self.partner_id.user_id or self.partner_id.commercial_partner_id.user_id   
    
    @api.depends('room_line_ids.tax_id', 'room_line_ids.price_unit', 'amount_total', 'amount_untaxed')
    def _compute_tax_totals_json(self):
        def compute_taxes(room_line_ids):
            price = room_line_ids.price_unit * (1 - (room_line_ids.discount or 0.0) / 100.0)
            order = room_line_ids.line_id
            return room_line_ids.tax_id._origin.compute_all(price, order.currency_id, room_line_ids.product_uom_qty, product=room_line_ids.product_id, partner=order.partner_shipping_id)

        account_move = self.env['account.move']
        for order in self:
            tax_lines_data = account_move._prepare_tax_lines_data_for_totals_from_object(order.room_line_ids, compute_taxes)
            tax_totals = account_move._get_tax_totals(order.partner_id, tax_lines_data, order.amount_total, order.amount_untaxed, order.currency_id)
            order.tax_totals_json = json.dumps(tax_totals)
            
    
    
    def _find_email_template(self, force_confirmation_template=False):
        template_id = False

        if force_confirmation_template or (self.state == 'draft'):
            template_id = int(self.env['ir.config_parameter'].sudo().get_param('hotel.email_template_hotel_quotation'))
            template_id = self.env['mail.template'].search([('id', '=', template_id)]).id
            if not template_id:
                template_id = self.env['ir.model.data']._xmlid_to_res_id('hotel.email_template_hotel_quotation', raise_if_not_found=False)
        if not template_id:
            template_id = self.env['ir.model.data']._xmlid_to_res_id('hotel.email_template_hotel_quotation', raise_if_not_found=False)

        return template_id

    
    def action_send_quotation_email(self):
        """
        This function opens a window to compose an email,
        template message loaded by default.
        @param self: object pointer
        """
        self.ensure_one(), "This is for a single id at a time."
        template_id = self._find_email_template()
        lang = self.env.context.get('lang')
        template = self.env['mail.template'].browse(template_id)
        if template.lang:
            lang = template._render_lang(self.ids)[self.id]
            
        ctx = {
            "default_model": "hotel.quotation",
            "default_res_id": self.ids[0],
            "default_use_template": bool(template_id),
            "default_template_id": template_id,
            "default_composition_mode": "comment",
            "force_send": True,
            "mark_so_as_sent": True,
            'force_email': True,
#             'model_description': self.with_context(lang=lang).type_name,
        }
        
        self.write({ "state": "sent"})

        return {
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "mail.compose.message",
            "views": [(False, "form")],
            "view_id": False,
            "target": "new",
            "context": ctx,
            "force_send": True,
        }
    
    @api.depends('room_line_ids.price_total')
    def _amount_all(self):
        """
        Compute the total amounts of the SO.
        """
        for order in self:
            amount_untaxed = amount_tax = 0.0
            for line in order.room_line_ids:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
            order.update({
                'amount_untaxed': amount_untaxed,
                'amount_tax': amount_tax,
                'amount_total': amount_untaxed + amount_tax,
            })
    
    def _update_folio_line(self, quotation_id):
        folio_room_line_obj = self.env["quotation.room.line"]
        hotel_room_obj = self.env["hotel.room"]
        for rec in quotation_id:
            for room_rec in rec.room_line_ids:
                room = hotel_room_obj.search(
                    [("product_id", "=", room_rec.product_id.id)]
                )
                room.write({"isroom": False})
                vals = {
                    "room_id": room.id,
                    "check_in": rec.checkin_date,
                    "check_out": rec.checkout_date,
                    "quotation_id": rec.id,
                }
                folio_room_line_obj.create(vals)     
    
    @api.model
    def create(self, vals):
        """
        Overrides orm create method.
        @param self: The object pointer
        @param vals: dictionary of fields value.
        @return: new record set for hotel folio.
        """
        if "quotation_id" in vals:
            tmp_room_lines = vals.get("room_line_ids", [])
            vals["order_policy"] = vals.get("hotel_policy", "manual")
            vals.update({"room_line_ids": []})
            quotation_id = super(HotelQuotation, self).create(vals)
            for line in tmp_room_lines:
                line[2].update({"quotation_id": quotation_id.id})
            vals.update({"room_line_ids": tmp_room_lines})
            quotation_id.write(vals)
        else:
            if not vals:
                vals = {}
            vals["name"] = self.env["ir.sequence"].next_by_code("hotel.quotation")
            vals["duration"] = vals.get("duration", 0.0) or vals.get("duration", 0.0)
            quotation_id = super(HotelQuotation, self).create(vals)
            self._update_folio_line(quotation_id)
        return quotation_id

    def write(self, vals):
        """
        Overrides orm write method.
        @param self: The object pointer
        @param vals: dictionary of fields value.
        """
        product_obj = self.env["product.product"]
        hotel_room_obj = self.env["hotel.room"]
        folio_room_line_obj = self.env["quotation.room.line"]
        for rec in self:
            rooms_list = [res.product_id.id for res in rec.room_line_ids]
            if vals and vals.get("duration", False):
                vals["duration"] = vals.get("duration", 0.0)
            else:
                vals["duration"] = rec.duration
            room_lst = [folio_rec.product_id.id for folio_rec in rec.room_line_ids]
            new_rooms = set(room_lst).difference(set(rooms_list))
            if len(list(new_rooms)) != 0:
                room_list = product_obj.browse(list(new_rooms))
                for rm in room_list:
                    room_obj = hotel_room_obj.search([("product_id", "=", rm.id)])
                    room_obj.write({"isroom": False})
                    vals = {
                        "room_id": room_obj.id,
                        "check_in": rec.checkin_date,
                        "check_out": rec.checkout_date,
                        "quotation_id": rec.id,
                    }
                    folio_room_line_obj.create(vals)
            if not len(list(new_rooms)):
                room_list_obj = product_obj.browse(rooms_list)
                for room in room_list_obj:
                    room_obj = hotel_room_obj.search([("product_id", "=", room.id)])
                    room_obj.write({"isroom": False})
                    room_vals = {
                        "room_id": room_obj.id,
                        "check_in": rec.checkin_date,
                        "check_out": rec.checkout_date,
                        "quotation_id": rec.id,
                    }
                    folio_romline_rec = folio_room_line_obj.search(
                        [("quotation_id", "=", rec.id)]
                    )
                    folio_romline_rec.write(room_vals)
        return super(HotelQuotation, self).write(vals)
    
    @api.constrains("room_line_ids")
    def _check_duplicate_folio_room_line(self):
        """
        This method is used to validate the room_lines.
        ------------------------------------------------
        @param self: object pointer
        @return: raise warning depending on the validation
        """
        for rec in self:
            for product in rec.room_line_ids.mapped("product_id"):
                for line in rec.room_line_ids.filtered(
                    lambda l: l.product_id == product
                ):
                    record = rec.room_line_ids.search(
                        [
                            ("product_id", "=", product.id),
                            ("quotation_id", "=", rec.id),
                            ("id", "!=", line.id),
                            ("checkin_date", ">=", line.checkin_date),
                            ("checkout_date", "<=", line.checkout_date),
                        ]
                    )
                    if record:
                        raise ValidationError(
                            _(
                                """Billboard Duplicate Exceeded!, """
                                """You Cannot Take Same %s Billboard Twice!"""
                            )
                            % (product.name)
                        )
                       
                    
#     def copy_data(self, default=None):
#         """
#         @param self: object pointer
#         @param default: dict of default values to be set
#         """
#         self.reservation_id.no_of_folio += 1
#         quotation_line_obj = self.room_line_ids
#         return quotation_line_obj.copy_data(default=default)
    
    def action_sales_order(self):
        self.write({"state": "sale"})
        
    def action_confirm(self):
        for order in self.room_line_ids:
            order.state = "sale"
#             if not order.analytic_account_id:
#                 if order.filtered(
#                     lambda line: line.product_id.invoice_policy == "cost"
#                 ):
#                     order._create_analytic_account()
            config_parameter_obj = self.env["ir.config_parameter"]
            if config_parameter_obj.sudo().get_param("sale.auto_done_setting"):
                self.room_line_ids.quotation_id.action_done()
                    
    @api.model
    def create(self, vals):
        """
        Overrides orm create method.
        @param self: The object pointer
        @param vals: dictionary of fields value.
        @return: new record set for hotel folio.
        """
        if "quotation_id" in vals:
            tmp_room_lines = vals.get("room_line_ids", [])
            vals["order_policy"] = vals.get("hotel_policy", "manual")
            vals.update({"room_line_ids": []})
            quotation_id = super(HotelQuotation, self).create(vals)
            for line in tmp_room_lines:
                line[2].update({"quotation_id": quotation_id.id})
            vals.update({"room_line_ids": tmp_room_lines})
            quotation_id.write(vals)
        else:
            if not vals:
                vals = {}
            vals["name"] = self.env["ir.sequence"].next_by_code("hotel.quotation")
            vals["duration"] = vals.get("duration", 0.0) or vals.get("duration", 0.0)
            quotation_id = super(HotelQuotation, self).create(vals)
            self._update_folio_line(quotation_id)
        return quotation_id
    
    def write(self, vals):
        """
        Overrides orm write method.
        @param self: The object pointer
        @param vals: dictionary of fields value.
        """
        product_obj = self.env["product.product"]
        hotel_room_obj = self.env["hotel.room"]
        folio_room_line_obj = self.env["quotation.room.line"]
        for rec in self:
            rooms_list = [res.product_id.id for res in rec.room_line_ids]
            if vals and vals.get("duration", False):
                vals["duration"] = vals.get("duration", 0.0)
            else:
                vals["duration"] = rec.duration
            room_lst = [folio_rec.product_id.id for folio_rec in rec.room_line_ids]
            new_rooms = set(room_lst).difference(set(rooms_list))
            if len(list(new_rooms)) != 0:
                room_list = product_obj.browse(list(new_rooms))
                for rm in room_list:
                    room_obj = hotel_room_obj.search([("product_id", "=", rm.id)])
                    room_obj.write({"isroom": False})
                    vals = {
                        "room_id": room_obj.id,
                        "check_in": rec.checkin_date,
                        "check_out": rec.checkout_date,
                        "quotation_id": rec.id,
                    }
                    folio_room_line_obj.create(vals)
            if not len(list(new_rooms)):
                room_list_obj = product_obj.browse(rooms_list)
                for room in room_list_obj:
                    room_obj = hotel_room_obj.search([("product_id", "=", room.id)])
                    room_obj.write({"isroom": False})
                    room_vals = {
                        "room_id": room_obj.id,
                        "check_in": rec.checkin_date,
                        "check_out": rec.checkout_date,
                        "quotation_id": rec.id,
                    }
                    folio_romline_rec = folio_room_line_obj.search(
                        [("quotation_id", "=", rec.id)]
                    )
                    folio_romline_rec.write(room_vals)
        return super(HotelQuotation, self).write(vals)
    
    
    
    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        """
        When you change partner_id it will update the partner_invoice_id,
        partner_shipping_id and pricelist_id of the hotel folio as well
        ---------------------------------------------------------------
        @param self: object pointer
        """
        if self.partner_id:
            self.update(
                {
                    "partner_invoice_id": self.partner_id.id,
                    "partner_shipping_id": self.partner_id.id,
                    "pricelist_id": self.partner_id.property_product_pricelist.id,
                }
            )

            
class HotelQuotationLine(models.Model):

    _name = "hotel.quotation.line"
    _description = "Hotel Quotation Line"

    
    price_subtotal = fields.Monetary(compute='_compute_amount', string='Subtotal', store=True)
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    currency_id = fields.Many2one()
    name = fields.Text(string='Description', required=True)
    
    billboard_id = fields.Many2one('hotel.room' , string = "Billboard No")
    
    product_id = fields.Many2one(
        'product.product', string='Product', domain="[('sale_ok', '=', True), '|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        change_default=True, ondelete='restrict', check_company=True)  # Unrequired company
    
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', domain="[('category_id', '=', product_uom_category_id)]", ondelete="restrict")
    product_uom_qty = fields.Float(string='Quantity', digits='Product Unit of Measure', required=True, default=1.0)
    company_id = fields.Many2one(related='quotation_id.company_id', string='Company', store=True, index=True)    
    checkin_date = fields.Datetime("Start Date", required=True)
    checkout_date = fields.Datetime("End Date", required=True)
    is_reserved = fields.Boolean(help="True when folio line created from Reservation")
    price_unit = fields.Float('Unit Price', required=True, digits='Product Price', default=0.0)
    discount = fields.Float(string='Discount (%)', digits='Discount', default=0.0)
    price_tax = fields.Float(compute='_compute_amount', string='Total Tax', store=True)
    price_total = fields.Monetary(compute='_compute_amount', string='Total', store=True)
    tax_id = fields.Many2many('account.tax', string='Taxes', context={'active_test': False})
    state = fields.Selection(
        related='quotation_id.state', string='Order Status', copy=False, store=True)
    
    quotation_id = fields.Many2one("hotel.quotation", "Quotation", ondelete="cascade")
    line_id = fields.Many2one("hotel.quotation")
    
    height = fields.Float("Height")
    width = fields.Float("Width")
    
    image = fields.Binary("Image",related="product_id.image_1920",readonly= True)

    partner_shipping_id = fields.Many2one(
        'res.partner', string='Delivery Address', readonly=True,
        states={'draft': [('readonly', False)], 'sent': [('readonly', False)], 'sale': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",)
    
    @api.depends('product_uom_qty', 'discount', 'price_unit', 'tax_id')
    def _compute_amount(self):
        """
        Compute the amounts of the SO line.
        """
        for line in self:
#             price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            price = 17 * line.width * line.height
            taxes = line.tax_id.compute_all(price, line.currency_id, line.product_uom_qty, product=line.product_id, partner=line.partner_shipping_id)
            line.update({
                'price_tax': sum(t.get('amount', 0.0) for t in taxes.get('taxes', [])),
                'price_total': taxes['total_included'],
                'price_subtotal': taxes['total_excluded'],
            })
            if self.env.context.get('import_file', False) and not self.env.user.user_has_groups('account.group_account_manager'):
                line.tax_id.invalidate_cache(['invoice_repartition_line_ids'], [line.tax_id.id])
                
                
    @api.model
    def create(self, vals):
        """
        Overrides orm create method.
        @param self: The object pointer
        @param vals: dictionary of fields value.
        @return: new record set for hotel folio line.
        """
        if "quotation_id" in vals:
            folio = self.env["hotel.quotation"].browse(vals["quotation_id"])
#             vals.update({"order_id": folio.order_id.id})
        return super(HotelQuotationLine, self).create(vals)

    @api.constrains("checkin_date", "checkout_date")
    def _check_dates(self):
        """
        This method is used to validate the checkin_date and checkout_date.
        -------------------------------------------------------------------
        @param self: object pointer
        @return: raise warning depending on the validation
        """
        if self.checkin_date >= self.checkout_date:
            raise ValidationError(
                _(
                    """Billboard line Start Date Should be """
                    """less than the End Date!"""
                )
            )
        if self.quotation_id.date_order and self.checkin_date:
            if self.checkin_date.date() < self.quotation_id.date_order.date():
                raise ValidationError(
                    _(
                        """Billboard line Start date should be """
                        """greater than the current date."""
                    )
                )
                
    def _get_display_price(self, product):
        # TO DO: move me in master/saas-16 on sale.order
        if self.quotation_id.pricelist_id.discount_policy == "with_discount":
            return product.with_context(pricelist=self.quotation_id.pricelist_id.id).price
        product_context = dict(
            self.env.context,
            partner_id=self.quotation_id.partner_id.id,
            date=self.quotation_id.date_order,
            uom=self.product_uom.id,
        )
        final_price, rule_id = self.quotation_id.pricelist_id.with_context(
            **product_context
        ).get_product_price_rule(
            self.product_id,
            self.product_uom_qty or 1.0,
            self.quotation_id.partner_id,
        )
        base_price, currency_id = self.with_context(
            **product_context
        )._get_real_price_currency(
            product,
            rule_id,
            self.product_uom_qty,
            self.product_uom,
            self.quotation_id.pricelist_id.id,
        )
        if currency_id != self.quotation_id.pricelist_id.currency_id.id:
            base_price = (
                self.env["res.currency"]
                .browse(currency_id)
                .with_context(**product_context)
                .compute(base_price, self.quotation_id.pricelist_id.currency_id)
            )
        # negative discounts (= surcharge) are included in the display price
        return max(base_price, final_price)
    
    
    def action_done(self):
        self.write({"state": "done"})

#     def action_cancel(self):
#         """
#         @param self: object pointer
#         """
#         for rec in self:
#             if not rec.quotation_id:
#                 raise UserError(_("Quotation id is not available"))
#             for product in rec.room_line_ids.filtered(
#                 lambda l: l.order_line_id.product_id == product
#             ):
#                 rooms = self.env["hotel.room"].search([("product_id", "=", product.id)])
#                 rooms.write({"isroom": True, "status": "available"})
#             rec.invoice_ids.button_cancel()
#             return rec.order_id.action_cancel()
    
       
    
#     def action_confirm(self):
#         for order in self.order_id:
#             order.state = "sale"
#             if not order.analytic_account_id:
#                 if order.order_line.filtered(
#                     lambda line: line.product_id.invoice_policy == "cost"
#                 ):
#                     order._create_analytic_account()
#             config_parameter_obj = self.env["ir.config_parameter"]
#             if config_parameter_obj.sudo().get_param("sale.auto_done_setting"):
#                 self.order_id.action_done()

#     def action_cancel_draft(self):
#         """
#         @param self: object pointer
#         """
#         order_line_recs = self.env["sale.order.line"].search(
#             [("order_id", "in", self.ids), ("state", "=", "cancel")]
#         )
#         self.write({"state": "draft", "invoice_ids": []})
#         order_line_recs.write(
#             {
#                 "invoiced": False,
#                 "state": "draft",
#                 "invoice_lines": [(6, 0, [])],
#             }
#         )

#     def unlink(self):
#         """
#         Overrides orm unlink method.
#         @param self: The object pointer
#         @return: True/False.
#         """
#         for line in self:
#             if line.order_line_id:
#                 rooms = self.env["hotel.room"].search(
#                     [("product_id", "=", line.order_line_id.product_id.id)]
#                 )
#                 folio_room_lines = self.env["folio.room.line"].search(
#                     [
#                         ("quotation_id", "=", line.quotation_id.id),
#                         ("room_id", "in", rooms.ids),
#                     ]
#                 )
#                 folio_room_lines.unlink()
#                 rooms.write({"isroom": True, "status": "available"})
#                 line.order_line_id.unlink()
#         return super(HotelQuotationLine, self).unlink()

    def _get_real_price_currency(self, product, rule_id, qty, uom, pricelist_id):
        """Retrieve the price before applying the pricelist
        :param obj product: object of current product record
        :parem float qty: total quentity of product
        :param tuple price_and_rule: tuple(price, suitable_rule) coming
        from pricelist computation
        :param obj uom: unit of measure of current order line
        :param integer pricelist_id: pricelist id of sale order"""
        PricelistItem = self.env["product.pricelist.item"]
        field_name = "lst_price"
        currency_id = None
        product_currency = None
        if rule_id:
            pricelist_item = PricelistItem.browse(rule_id)
            if pricelist_item.pricelist_id.discount_policy == "without_discount":
                while (
                    pricelist_item.base == "pricelist"
                    and pricelist_item.base_pricelist_id
                    and pricelist_item.base_pricelist_id.discount_policy
                    == "without_discount"
                ):
                    price, rule_id = pricelist_item.base_pricelist_id.with_context(
                        uom=uom.id
                    ).get_product_price_rule(product, qty, self.quotation_id.partner_id)
                    pricelist_item = PricelistItem.browse(rule_id)

            if pricelist_item.base == "standard_price":
                field_name = "standard_price"
            if pricelist_item.base == "pricelist" and pricelist_item.base_pricelist_id:
                field_name = "price"
                product = product.with_context(
                    pricelist=pricelist_item.base_pricelist_id.id
                )
                product_currency = pricelist_item.base_pricelist_id.currency_id
            currency_id = pricelist_item.pricelist_id.currency_id

        product_currency = (
            product_currency
            or (product.company_id and product.company_id.currency_id)
            or self.env.user.company_id.currency_id
        )
        if not currency_id:
            currency_id = product_currency
            cur_factor = 1.0
        else:
            if currency_id.id == product_currency.id:
                cur_factor = 1.0
            else:
                cur_factor = currency_id._get_conversion_rate(
                    product_currency, currency_id
                )

        product_uom = self.env.context.get("uom") or product.uom_id.id
        if uom and uom.id != product_uom:
            # the unit price is in a different uom
            uom_factor = uom._compute_price(1.0, product.uom_id)
        else:
            uom_factor = 1.0
        return product[field_name] * uom_factor * cur_factor, currency_id.id

    def _get_display_price(self, product):
        # TO DO: move me in master/saas-16 on sale.order
        if self.quotation_id.pricelist_id.discount_policy == "with_discount":
            return product.with_context(pricelist=self.quotation_id.pricelist_id.id).price
        product_context = dict(
            self.env.context,
            partner_id=self.quotation_id.partner_id.id,
            date=self.quotation_id.date_order,
            uom=self.product_uom.id,
        )
        final_price, rule_id = self.quotation_id.pricelist_id.with_context(
            **product_context
        ).get_product_price_rule(
            self.product_id,
            self.product_uom_qty or 1.0,
            self.quotation_id.partner_id,
        )
        base_price, currency_id = self.with_context(
            **product_context
        )._get_real_price_currency(
            product,
            rule_id,
            self.product_uom_qty,
            self.product_uom,
            self.quotation_id.pricelist_id.id,
        )
        if currency_id != self.quotation_id.pricelist_id.currency_id.id:
            base_price = (
                self.env["res.currency"]
                .browse(currency_id)
                .with_context(**product_context)
                .compute(base_price, self.quotation_id.pricelist_id.currency_id)
            )
        return max(base_price, final_price)

#     def _compute_tax_id(self):
#         for line in self:
#             line = line.with_company(line.company_id)
#             fpos = (
#                 line.order_id.fiscal_position_id
#                 or line.order_id.fiscal_position_id.get_fiscal_position(
#                     line.order_partner_id.id
#                 )
#             )
#             # If company_id is set, always filter taxes by the company
#             taxes = line.product_id.taxes_id.filtered(
#                 lambda t: t.company_id == line.env.company
#             )
#             line.tax_id = fpos.map_tax(taxes)

    def _compute_tax_id(self):
        for line in self:
            line = line.with_company(line.company_id)
            fpos = (
                line.line_id.fiscal_position_id
                or line.line_id.fiscal_position_id.get_fiscal_position(
                    line.line_id.partner_id.id
                )
            )
            # If company_id is set, always filter taxes by the company
            taxes = line.product_id.taxes_id.filtered(
                lambda t: t.company_id == line.env.company
            )
            line.tax_id = fpos.map_tax(taxes)
    
    
    @api.onchange("product_id")
    def _onchange_product_id(self):
        if not self.product_id:
            return
        product_tmpl = self.product_id.product_tmpl_id
        attribute_lines = product_tmpl.valid_product_template_attribute_line_ids
        valid_values = attribute_lines.product_template_value_ids
        # remove the is_custom values that don't belong to this template
#         for pacv in self.product_custom_attribute_value_ids:
#             if pacv.custom_product_template_attribute_value_id not in valid_values:
#                 self.product_custom_attribute_value_ids -= pacv

        # remove the no_variant attributes that don't belong to this template
#         for ptav in self.product_no_variant_attribute_value_ids:
#             if ptav._origin not in valid_values:
#                 self.product_no_variant_attribute_value_ids -= ptav

        vals = {}
        if not self.product_uom or (self.product_id.uom_id.id != self.product_uom.id):
            vals["product_uom"] = self.product_id.uom_id
            vals["product_uom_qty"] = self.product_uom_qty or 1.0

        product = self.product_id.with_context(
            lang=get_lang(self.env, self.line_id.partner_id.lang).code,
            partner=self.line_id.partner_id,
            quantity=vals.get("product_uom_qty") or self.product_uom_qty,
            date=self.line_id.date_order,
            pricelist=self.line_id.pricelist_id.id,
            uom=self.product_uom.id,
        )

#         vals.update(
#             name=self.order_line_id.get_sale_order_line_multiline_description_sale(
#                 product
#             )
#         )

        self._compute_tax_id()

        if self.quotation_id.pricelist_id and self.quotation_id.partner_id:
            vals["price_unit"] = self.env[
                "account.tax"
            ]._fix_tax_included_price_company(
                self._get_display_price(product),
                product.taxes_id,
                self.tax_id,
                self.company_id,
            )
        self.update(vals)

        title = False
        message = False
        result = {}
        warning = {}
        if product.sale_line_warn != "no-message":
            title = _("Warning for %s", product.name)
            message = product.sale_line_warn_msg
            warning["title"] = title
            warning["message"] = message
            result = {"warning": warning}
            if product.sale_line_warn == "block":
                self.product_id = False
        return result

    
    
    @api.onchange("checkin_date", "checkout_date")
    def _onchange_checkin_checkout_dates(self):
        """
        When you change checkin_date or checkout_date it will checked it
        and update the qty of hotel folio line
        -----------------------------------------------------------------
        @param self: object pointer
        """
            
        configured_addition_hours = (
            self.quotation_id.company_id.additional_hours
        )
        myduration = 0
        if self.checkin_date and self.checkout_date:
            dur = self.checkout_date - self.checkin_date
            sec_dur = dur.seconds
            if (not dur.days and not sec_dur) or (dur.days and not sec_dur):
                myduration = dur.days
            else:
                myduration = dur.days + 1
            #            To calculate additional hours in hotel room as per minutes
            if configured_addition_hours > 0:
                additional_hours = abs((dur.seconds / 60) / 60)
                if additional_hours >= configured_addition_hours:
                    myduration += 1
        self.product_uom_qty = myduration

#     def copy_data(self, default=None):
#         """
#         @param self: object pointer
#         @param default: dict of default values to be set
#         """
#         sale_line_obj = self.order_line_id
#         return sale_line_obj.copy_data(default=default)
