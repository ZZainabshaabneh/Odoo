from odoo import models, fields, api
import requests
import json
import random
from datetime import datetime


class bisan(models.Model):
    PRICELIST_CURRENCY_MAPPING = {
    1: "01", #USD
    2: "02", #ILS
    3: "03", #JOD
    4: "04", # EUR
    # Add more mappings if needed
}
    
    
    PRICELIST_CURRENCY_MAPPING_2 = {
    2: "01", 
    88: "02",
    90: "03",
    1: "04",
    # Add more mappings if needed
}

    _name = 'bisan.bisan'
    _description = 'bisan.bisan'

    name = fields.Char()
    value = fields.Integer()
    value2 = fields.Float(compute="_value_pc", store=True)
    description = fields.Text()
    # accessToken = fields.Text( readonly=False)

    last_imported_timestamp = fields.Datetime(string='Last Imported Timestamp', readonly=True)
    
    APP_ID='SKYCRM'
    APP_SECRET='QJEIS8j7A0LNolLb6tc8SREJPzy6wg7OnACwOKON'
    
    accessToken = ""  # Declare accessToken as a class-level attribute
    
    base_url="https://gw.bisan.com/api/v2/sky"
    username="odoo"
    password="Bisan@2023"

    

    def generate_transaction_id(self):
        def s4():
            return str(random.randint(0, 9999)).zfill(4)

        return s4() + s4()
        
    def login(self):
 
        url = bisan.base_url + "/login"

        payload = json.dumps({
          "user": bisan.username,
          "password": bisan.password
        })
        headers = {
          'BSN-apiID': bisan.APP_ID,
          'BSN-apiSecret': bisan.APP_SECRET,
          'Content-Type': 'application/json'
        }
        
        response = requests.request("POST", url, headers=headers, data=payload)
        response_data = response.json()
        bisan.accessToken = response_data.get('token')
         # Assign the accessToken valuez

   
# 
        
    
    # @api.model
    # def create(self, vals):
    #     # This method is called when a record is created
    #     self.accessToken = self.login()  # Assign the accessToken value

    #     return super(bisan, self).create(vals)
    
    def send_invoice(self, order_id):
        
    
        url = bisan.base_url+"/salesOrder"
        transaction_id = self.generate_transaction_id()
        sales_order = self.env['sale.order'].sudo().browse(order_id)
        if not sales_order:
            print("Sales order not found.")
            return
        pricelist_id = sales_order.pricelist_id.id
        currency = self.PRICELIST_CURRENCY_MAPPING.get(pricelist_id, "03")  
        order_details = []
        for line in sales_order.order_line:
            order_details.append({
                "item": line.product_id.default_code,
                "quantity": str(line.product_uom_qty),
                "price": str(line.price_unit),
            })

        payload = json.dumps({
          "TRANSACTION_ID": transaction_id,
          "record": {
            "comment": f"BR#: {sales_order.name}",
            "currency": currency,
            "customerTaxType": "E",
            "contact": sales_order.partner_id.x_studio_code,
            "cusReference": "1122",
            "orderDetail": order_details 
          }
        })
        headers = {
          'BSN-token': bisan.accessToken,  # Use the accessToken
        
          'Content-Type': 'application/json'
        }
        
        response = requests.request("POST", url, headers=headers, data=payload)
        
        print(response.text)

    def send_po(self, order_id):
      
        url = bisan.base_url+"/purchaseOrder"
        transaction_id = self.generate_transaction_id()
        purchase_order = self.env['purchase.order'].sudo().browse(order_id)
        if not purchase_order:
            print("Sales order not found.")
            return
        pricelist_id = purchase_order.currency_id.id
        currency = self.PRICELIST_CURRENCY_MAPPING_2.get(pricelist_id, "03")  
        order_details = []
        for line in purchase_order.order_line:
            order_details.append({
                "item": line.product_id.default_code,
                "quantity": str(line.product_uom_qty),
                "price": str(line.price_unit),
            })

        payload = json.dumps({
          "TRANSACTION_ID": transaction_id,
          "record": {
            "comment": f"BR#: {purchase_order.partner_ref} ",
            "currency": currency,
            "customerTaxType": "E",
            "contact": purchase_order.partner_id.x_studio_code,
            "cusReference": "1122",
            "project":purchase_order.origin,
            "orderDetail": order_details 
          }
        })
        headers = {
          
          'BSN-token': bisan.accessToken,  # Use the accessToken
          'Content-Type': 'application/json'
        }
        
        response = requests.request("POST", url, headers=headers, data=payload)
        
        print(response.text)
        
    def create_project(self, order_id):
      
        url = bisan.base_url+"/projectTb"
        transaction_id = self.generate_transaction_id()
        sales_order = self.env['sale.order'].sudo().browse(order_id)
        if not sales_order:
            print("Sales order not found.")
            return
        pricelist_id = sales_order.pricelist_id.id
        currency = self.PRICELIST_CURRENCY_MAPPING.get(pricelist_id, "03")  
        # order_details = []
        # for line in sales_order.order_line:
        #     order_details.append({
        #         "item": line.product_id.default_code,
        #         "quantity": str(line.product_uom_qty),
        #         "price": str(line.price_unit),
        #     })

        payload = json.dumps({
          "TRANSACTION_ID": transaction_id,
          "record": {
            "code": sales_order.name,
            "nameEN": sales_order.projectname,
            "nameAR": sales_order.projectname,
            # "contact": sales_order.partner_id.x_studio_code,
            # "cusReference": "1122",
            # "orderDetail": order_details 
          }
        })
        headers = {
          'BSN-token': bisan.accessToken,  # Use the accessToken
        
          'Content-Type': 'application/json'
        }
        
        response = requests.request("POST", url, headers=headers, data=payload)
        
        print(response.text)        
  

    def import_contacts(self):
        url = bisan.base_url + "/contact?fields=code,name,phone,nameEN,nameAR,isCustomer,isSupplier"
        headers = {
            'BSN-token': bisan.accessToken,
            'BSN-add-last-changed': 'true'
        }
    
        response = requests.get(url, headers=headers)
        api_response = response.json().get('rows', [])
    
        partner_obj = self.env['res.partner']
        for contact_data in api_response:
            contact_code = contact_data["code"]
            existing_contact = partner_obj.search([('x_studio_code', '=', contact_code)], limit=1)
    
            if not existing_contact:
                new_contact = {
                    "name": contact_data.get("nameEN", contact_data.get("nameAR")),
                    "x_studio_code": contact_code,
                    "x_studio_supplier": contact_data["isSupplier"] == "نعم",
                    "x_studio_customer": contact_data["isCustomer"] == "نعم",
                    # Add more fields as needed
                    # Add more fields as needed
                }
                partner_obj.create(new_contact)
    
        return True
    def import_products(self):
        url = bisan.base_url+ "/item?fields=code,name"
        headers = {
            'BSN-token': bisan.accessToken,
        }
    
        response = requests.get(url, headers=headers)
        api_response = response.json().get('rows', [])
    
        product_obj = self.env['product.product']
        for product_data in api_response:
            product_code = product_data["code"]
            existing_product = product_obj.search([('default_code', '=', product_code)], limit=1)
    
            if not existing_product:
                new_product = {
                    "name": product_data["name"],
                    "default_code": product_code,
                    # Add more fields as needed
                }
                product_obj.create(new_product)
    
        return True

    @api.depends('value')
    def _value_pc(self):
        for record in self:
            record.value2 = float(record.value) / 100
