# -*- coding: utf-8 -*-
# from odoo import http


# class Bisan(http.Controller):
#     @http.route('/bisan/bisan', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/bisan/bisan/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('bisan.listing', {
#             'root': '/bisan/bisan',
#             'objects': http.request.env['bisan.bisan'].search([]),
#         })

#     @http.route('/bisan/bisan/objects/<model("bisan.bisan"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('bisan.object', {
#             'object': obj
#         })
