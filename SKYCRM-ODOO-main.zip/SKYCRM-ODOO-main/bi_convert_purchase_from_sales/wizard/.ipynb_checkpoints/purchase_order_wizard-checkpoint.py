# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
from odoo.exceptions import UserError, ValidationError
import time, json
from odoo import api, fields, models, _
from datetime import datetime
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError


class createpurchaseorder(models.TransientModel):
        _name = 'create.purchaseorder'
        _description = "Create Purchase Order"

        new_order_line_ids = fields.One2many( 'getsale.orderdata', 'new_order_line_id',string="Order Line")
        partner_id = fields.Many2one('res.partner', string='Vendor', required = True)
        date_order = fields.Datetime(string='Order Date', required=True, copy=False, default=fields.Datetime.now)
        vendor_id = fields.Char()
        projectname = fields.Char("Project Name")
        pricelist_id = fields.Many2one("product.pricelist" , string= "Pricelist")
        customer_id = fields.Many2one("res.partner", string = "Customer")
        # tachs_id = fields.Many2many('account.tax', string = "Tax")
#         vendor_id = fields.Many2one('res.partner', string='Sale Order', required = True)

        @api.onchange('new_order_line_ids')
        def _compute_vendor_domain(self):
            vendor_list = []
            for record in self:
                for line in record.new_order_line_ids:
                        if line.vendor_edit:
                           vendor_list.append(line.vendor_edit.id)

            self.vendor_id = vendor_list
            return{'domain':{'partner_id':[('id','in',vendor_list)]}}                  
        
        
        @api.onchange('partner_id')
        def _onchange_partner_id(self): 
            vals = {'new_order_line_ids':[]}
            if self.partner_id:
                for line in self.new_order_line_ids:
                     if self.partner_id.id != line.vendor_edit.id:
                        vals['new_order_line_ids'].append([2,line.id, False])
                self.write(vals)
                
                
        
        @api.model
        def default_get(self,  default_fields):
            res = super(createpurchaseorder, self).default_get(default_fields)
            data = self.env['sale.order'].browse(self._context.get('active_ids',[]))
            update = []
            for record in data.order_line:
                res.update({'projectname':data.projectname})
                res.update({'pricelist_id':data.pricelist_id.id})
                res.update({'customer_id':data.partner_id.id})
                update.append((0,0,{
                                'product_id' : record.product_id.id,
                                'product_uom' : record.product_uom.id,
                                'order_id': record.order_id.id,
                                'name' : record.name,
                                'product_qty' : record.product_uom_qty,
                                'price_unit' : record.cost_edit,
                                'vendor_edit': record.vendor_edit,
                                'product_subtotal' : record.price_subtotal,
                                'tachs_id': record.tax_id.ids

                                }))
            res.update({'new_order_line_ids':update})
            
            return res

        def action_create_purchase_order(self):
            self.ensure_one()
            res = self.env['purchase.order'].browse(self._context.get('id',[]))
            value = []
            so = self.env['sale.order'].browse(self._context.get('active_id'))
            pricelist = self.partner_id.property_product_pricelist
            partner_pricelist = self.partner_id.property_product_pricelist
            sale_order_name = ""
#             for data in self.new_order_line_ids:
#                 if self.partner_id.id == data.vendor_edit.id:
#                     sale_order_name = data.order_id.name
#                     if not sale_order_name:
#                         sale_order_name = so.name
#                     if partner_pricelist:
#                         product_context = dict(self.env.context, partner_id=self.partner_id.id, date=self.date_order, uom=data.product_uom.id)
#                         final_price, rule_id = partner_pricelist.with_context(product_context).get_product_price_rule(data.product_id, data.product_qty or 1.0, self.partner_id)

#                     else:
#                         final_price = data.product_id.standard_price
#                     value.append([0,0,{
#                                         'product_id' : data.product_id.id,
#                                         'name' : data.name,
#                                         'product_qty' : data.product_qty,
#                                         'order_id':data.order_id.id,
#                                         'product_uom' : data.product_uom.id,
#                                         'taxes_id' : data.product_id.supplier_taxes_id.ids,
#                                         'date_planned' : data.date_planned,
#                                         'price_unit' : data.product_id.standard_price,

#                                         }])


            for data in self.new_order_line_ids:
                if self.partner_id.id == data.vendor_edit.id:
                    sale_order_name = data.order_id.name
                    if not sale_order_name:
                        sale_order_name = so.name
                    if partner_pricelist:
                        product_context = dict(self.env.context, partner_id=self.partner_id.id, date=self.date_order, uom=data.product_uom.id)
                        final_price, rule_id = partner_pricelist.with_context(product_context).get_product_price_rule(data.product_id, data.product_qty or 1.0, self.partner_id)

                    else:
                        final_price = data.product_id.standard_price
                    value.append([0,0,{
                                        'product_id' : data.product_id.id,
                                        'name' : data.name,
                                        'product_qty' : data.product_qty,
                                        'order_id': data.order_id.id,
                                        'product_uom' : data.product_uom.id,
                                        # 'taxes_id' : data.product_id.supplier_taxes_id.ids,
                                        'taxes_id' : data.tachs_id.ids,
                                        'date_planned' : data.date_planned,
                                        'price_unit' : data.price_unit,

                                        }])
            res.create({
                            'partner_id' : self.partner_id.id,
                            'customer_id' : self.customer_id.id,
                            'projectname' : self.projectname,
                            'currency_id' : self.pricelist_id.currency_id.id,
                            'date_order' : str(self.date_order),
                            'order_line':value,
                            'origin' : sale_order_name,
                            'partner_ref' : sale_order_name
                        })
            

            return res


class Getsaleorderdata(models.TransientModel):
        _name = 'getsale.orderdata'
        _description = "Get Sale Order Data"

        new_order_line_id = fields.Many2one('create.purchaseorder')

        product_id = fields.Many2one('product.product', string="Product", required=True)
        name = fields.Char(string="Description")
        product_qty = fields.Float(string='Quantity', required=True)
        date_planned = fields.Datetime(string='Scheduled Date', default = datetime.today())
        product_uom = fields.Many2one('uom.uom', string='Product Unit of Measure')
        order_id = fields.Many2one('sale.order', string='Order Reference', ondelete='cascade', index=True)
        price_unit = fields.Float(string='Unit Price', digits='Product Price')
        product_subtotal = fields.Float(string="Sub Total", compute='_compute_total')
        vendor_edit = fields.Many2one('res.partner' , string = "Vendor")
        projectname = fields.Char("Project Name")
        tachs_id = fields.Many2many('account.tax', string = "Taxes")
        
        
	
        @api.depends('product_qty', 'price_unit')
        def _compute_total(self):
            for record in self:
                record.product_subtotal = record.product_qty * record.price_unit
                     
            
class SaleorderInherit(models.Model):
    _inherit = 'sale.order'
    
    
    projectname = fields.Char("Project Name")
    vendor_domain = fields.Char(compute="_compute_vendor_domain")
    vendor_id = fields.Many2one("res.partner")
    total_cost = fields.Float("Total Cost",compute = "_compute_total_cost")
    
    def _compute_total_cost(self):
        total = 0
        for record in self:
            for line in record.order_line:
                total += line.subtotal_cost
        record.total_cost = total
    
    
    
    @api.model
    def create(self, vals):
        res = super(SaleorderInherit, self).create(vals)
        sl_no = 0
        for line in res.order_line:
            sl_no +=1
            line.sl_no = sl_no
            
        return res
        
    
#     @api.model
#     def create(self, vals):
#         res = super(SaleorderInherit, self).create(vals)
#         sl_no = 0
#         for line in res.order_line:
#             sl_no +=1
#             line.sl_no = sl_no
            
#         return res
    
                      
    
#     def specialCommand3(self):
#         vals = {'order_line':[]}
#         for record in self:
#             for line in record.order_line:
#                 if record.partner_id.id == line.vendor_edit.id:
#                    vals['order_line'].append([3,line.id,False])
#         self.write(vals) 
        
            
   
        
    @api.onchange('order_line')
    def _compute_vendor_domain(self):   
        vendor_list = []
        for record in self:
            for line in record.order_line:
                if line.vendor_edit:
                   vendor_list.append(line.vendor_edit.id)
                        
        self.vendor_domain = vendor_list
        return{'domain':{'vendor_id':[('id','in',vendor_list)]}}
    
    
    @api.onchange('vendor_id')
    def _onchange_vendor_id(self):                            
        for record in self:
             for line in record.order_line:
                if record.partner_id.id != line.vendor_edit.id:
#                     line.unlink()
                    repeatIn(filter( lambda l: l.partner_id.id=='vendor_edit.id' ,record.order_line), 'line')
	
    
    reservation = fields.Many2many("hotel.reservation","hotel_reseravtion_sale_order")


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'
	
    
    margin_edit = fields.Float("Margin (%)")
    vendor_edit = fields.Many2one('res.partner' , string = "Vendor")
    purchase_price = fields.Float("Purchase Price")
    cost_edit = fields.Float("Cost", digits = (2 , 5))
    sl_no = fields.Integer("#")
    subtotal_cost = fields.Float("Subtotal Cost", digits = (2 , 5))
    computemargin = fields.Selection([("margin", "Margin"),("price_unit", "Unit Price")],"Compute",default="price_unit")
    margin_report = fields.Float("Margin")
     
    
#     @api.depends('product_uom_qty','cost_edit')
#     def _compute_amount(self):
#         """
#         Compute the amounts of the SO line.
#         """
#         for line in self:
#             total_cost = line.product_uom_qty * line.cost_edit
#             line.update({
                
#                 'subtotal_edit': total_cost ,
#             })
   

#     @api.onchange('computemargin')
#     def _compute_margin(self):
#         for line in self:
#             if line.price_unit != 0:
#                 line.margin_edit = 100 * (line.price_unit - line.product_id.standard_price) / line.price_unit
        
    
    @api.onchange('margin_edit','product_uom_qty','cost_edit','price_unit','computemargin')
    def _compute_price_unit_based_on_margin(self):
        sum = 0
        for line in self:
            if line.computemargin == "price_unit" or "":
                line.product_id.standard_price = line.cost_edit
#                     price_unit = line.cost_edit*(1+(line.margin_edit/100))
#                     price_unit = line.cost_edit / ( 1 - (line.margin_edit/100) )
                price_unit = line.cost_edit * ((line.margin_edit/100)*100) + line.cost_edit
#                     price_unit = line.cost_edit / (line.margin_edit - 1)
#                     price_unit = ( 100 * line.cost_edit ) / ( 100 - line.margin_edit)
                line.product_id.lst_price = price_unit
                line.price_unit = price_unit
#                 line.product_id.standard_price = line.cost_edit
                line.subtotal_cost = line.product_uom_qty * line.cost_edit
    
                # line.subtotal_edit = line.product_uom_qty * line.cost_edit
        
        
                line.margin_report = line.margin_edit * 100
            elif line.computemargin == "margin":
#                 line.product_id.standard_price = line.cost_edit
                line.product_id.lst_price = line.price_unit
                if (line.cost_edit != 0):
                    line.margin_edit = ((line.price_unit - line.cost_edit) / line.cost_edit)
                else:  
                    raise ValidationError(_("Cost Price is Zero. Please add a Cost Price for product"))  
                
                line.margin_report = line.margin_edit * 100
            
#                 line.margin_edit = 100 * (line.price_unit - line.product_id.standard_price) / line.price_unit

    
    
            
#            for rec in self:
#                rec.vendor_domain = json.dumps([('partner_id', '=', rec.partner_id.id)])


            
    @api.depends('vendor_edit')
    def _compute_vendor_edit(self):
        
        vendor_list = []
        for line in self:
            if line.vendor_edit:
                vendor_list.append(line.vendor_edit)
      
                
# class RespartnerInherit(models.Model):
#     _inherit = 'res.partner'
#     _rec_name = "name"
    
#     code_edit = fields.Char(string="Code", default=" ", required = "1") 
    
    
#     def name_get(self):
#         return [(record.id," %s %s" % (record.code_edit,record.name)) for record in self]
        
            
    
#     if (rec.code == 'True'):
#                 fname = rec.name +" "+ "[" + rec.code + "]"
#             else:
#                 fname = str(rec.name)
        
    
    
class PurchaseorderInherit(models.Model):
    _inherit = 'purchase.order'
    
    projectname = fields.Char("Project Name")
    customer_id = fields.Many2one("res.partner", string = "Customer")
    
    @api.model
    def create(self, vals):
        res = super(PurchaseorderInherit, self).create(vals)
        sl_no = 0
        for line in res.order_line:
            sl_no +=1
            line.sl_no = sl_no
            
        return res
    
#     vendor_domain = fields.Char(compute="_compute_vendor_domain")
#     vendor_id = fields.Many2one("res.partner")
#     total_cost = fields.Float("Total Cost",compute = "_compute_total_cost")
    
#     def _compute_total_cost(self):
#         total = 0
#         for record in self:
#             for line in record.order_line:
#                 total += line.subtotal_cost
#         record.total_cost = total
    
    
#     @api.model
#     def create(self, vals):
#         res = super(PurchaseorderInherit, self).create(vals)
#         sl_no = 0
#         for line in res.order_line:
#             sl_no +=1
#             line.sl_no = sl_no
            
#         return res
    

class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'
    
    sl_no = fields.Integer("#")