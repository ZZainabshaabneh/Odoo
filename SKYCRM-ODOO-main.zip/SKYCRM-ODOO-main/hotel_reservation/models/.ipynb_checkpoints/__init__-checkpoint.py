# -*- coding: utf-8 -*-

from . import hotel_folio
from . import hotel_quick_reservation
from . import hotel_reservation
from . import hotel_room